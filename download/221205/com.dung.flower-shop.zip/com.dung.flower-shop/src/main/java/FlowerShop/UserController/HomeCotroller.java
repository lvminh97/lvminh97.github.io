package FlowerShop.UserController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeCotroller {
	@RequestMapping(value={"/","/trang-chu"} , method = RequestMethod.GET)
	public ModelAndView Index() {
		ModelAndView mv= new ModelAndView();
		mv.setViewName("user/index");
		return mv;
	}
}
